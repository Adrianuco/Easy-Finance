﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyFinance
{
    public partial class Form2 : Form
    {
        private Form1 ventana1;

        public static List<Gasto> gastos = new List<Gasto>();
        public static List<Ingreso> ingresos = new List<Ingreso>();

        public Form2(Form1 menu)
        {
            InitializeComponent();
            ventana1 = menu;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        int opc = -1;
        private void btnGuardar1_Click(object sender, EventArgs e)
        {
                switch (opc)
                {
                    case 1:
                    {
                        
                        string nombre = txtTransacción1.Text;
                        double monto = Convert.ToDouble(txtMonto1.Text);
                        string categoria = cmbCategoría1.Text;
                        DateTime fecha = dtpFecha.Value;

                        Gasto.registrarGasto(gastos, nombre, monto, fecha, categoria);
                        
                        foreach (Categoria cat in Form1.categorias)
                            {
                                if (cat.Nombre == categoria)
                                {
                                    cat.monto += monto;
                                    Categoria.calcularPorcentaje(cat);
                                    Categoria.verificarAlerta(cat);
                                    if(cat.Alerta)
                                    {
                                        MessageBox.Show("Alerta: " + cat.Nombre + " ha superado el límite de gasto");
                                    }
                                }
                            }
                        Archivos.guardarGastos(gastos);
                        Archivos.guardarCategorias(Form1.categorias);
                        break;
                    }
                    case 2:
                    {
                        
                        string nombre = txtTransacción1.Text;
                        double monto = Convert.ToDouble(txtMonto1.Text);
                        DateTime fecha = dtpFecha.Value;

                        Ingreso.registrarIngreso(ingresos, nombre, monto, fecha);
                        Archivos.guardarIngresos(ingresos);
                        break;
                    }
                   
                    default:
                    {
                        MessageBox.Show("Seleccione si es un gasto o un ingreso");
                        break;
                    }
                } 
            
            radGastos.Checked = false;
            radIngresos.Checked = false;
            txtTransacción1.Clear();
            txtMonto1.Clear();
            cmbCategoría1.Text = "";
            dtpFecha.Value = DateTime.Now;
            opc = -1;

        }

        private void btnRegresar1_Click(object sender, EventArgs e)
        {
            this.Close();
            ventana1.Visible = true;
        }

        private void RegresarMenu1(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Visible = false;
        }

        private void radGastos_CheckedChanged(object sender, EventArgs e)
        {
            if (radGastos.Checked)
            {
                opc = 1;
                cmbCategoría1.Enabled = true;
            }
            
        }

        private void radIngresos_CheckedChanged(object sender, EventArgs e)
        {
            if (radIngresos.Checked)
            {
                opc = 2;
                cmbCategoría1.Enabled = false;
            }
        }

        private void dtpFecha_ValueChanged(object sender, EventArgs e)
        {
            DateTime hoy = DateTime.Now;
            if (dtpFecha.Value.Month != hoy.Month)
            {
                MessageBox.Show("La fecha seleccionada no corresponde al mes actual. Por favor intente de nuevo.");
                dtpFecha.Value = hoy;
            }
        }
    }
}
