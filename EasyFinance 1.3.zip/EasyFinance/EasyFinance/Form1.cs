﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyFinance
{
    public partial class Form1 : Form
    {
        private Form2 ventana1;
        private Form3 ventana2;
        private Form4 ventana3;


        public static List<Categoria> categorias = new List<Categoria>();
        

        public Form1()
        {
            InitializeComponent();
            ventana1 = new Form2(this);
            ventana2 = new Form3(this);
            ventana3 = new Form4(this);
            Archivos.leerCategoria(categorias);
            Archivos.leerGastos(Form2.gastos);
            Archivos.leerIngresos(Form2.ingresos);
            DateTime hoy = DateTime.Now;
        }   

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            ventana1.Visible = true;
        }

        private void btnCategorías_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            ventana2.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnResumen_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            ventana3.Visible = true;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Archivos.guardarCategorias(categorias);
            Archivos.guardarGastos(Form2.gastos);
            Archivos.guardarIngresos(Form2.ingresos);
            Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("ALERTA! Esta opción generará un reporte del mes actual y reiniciará los datos para iniciar un nuevo ciclo mensual. ¿Está seguro que desea continuar?", "Advertencia", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);

            if (result == DialogResult.OK)
            {
                
            }
            
        }
    }
}
