﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EasyFinance
{
    public partial class Form3 : Form
    {
        private Form1 ventana1;

        public Form3(Form1 menu)
        {
            InitializeComponent();
            ventana1 = menu;
           
        }


        private void btnEditar_Click(object sender, EventArgs e)
        {
            txtLimite1.Text = txtLimite1.Text.Replace("C$", "");
            txtLimite1.Enabled = true;
            btnGuardar.Visible = true;
        }

        private void btnRegresar2_Click(object sender, EventArgs e)
        {
            this.Close();
            ventana1.Visible = true;
        }

        private void RegresarMenu2(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Visible = false;
        }

        int opc = -1;
        private void cmbCategoría2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCategoría2.Text == "Alimentos")
            {
                opc = 0;
            }
            if (cmbCategoría2.Text == "Transporte")
            {
                opc = 1;
            }
            if (cmbCategoría2.Text == "Entretenimiento")
            {
                opc = 2;
            }
            if (cmbCategoría2.Text == "Educacion")
            {
                opc = 3;
            }
            if (cmbCategoría2.Text == "Salud")
            {
                opc = 4;
            }
            if (cmbCategoría2.Text == "Otros")
            {
                opc = 5;
            }

            
            // Validar si opc está dentro del rango válido de la lista de categorías
            if (opc >= 0 && opc < Form1.categorias.Count)
            {
                lblSelect2.Text = Form1.categorias[opc].Nombre;
                
                
                    lblPorcentaje.Text = Convert.ToString(Form1.categorias[opc].Porcentaje_Gasto * 100) + "%";
                    txtLimite1.Text = "C$" + Convert.ToString(Form1.categorias[opc].Limite_Gasto);
                    try
                    {
                        prgGasto1.Value = Convert.ToInt32(Form1.categorias[opc].Porcentaje_Gasto * 100);
                    }
                    catch
                    {
                        prgGasto1.Value = 100;
                    }
              
            }
            else
            {
                // Mostrar mensaje si opc no es válido
                MessageBox.Show("Categoría no válida. Por favor, verifica la configuración.");
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Form1.categorias[opc].Limite_Gasto = Convert.ToDouble(txtLimite1.Text);
            txtLimite1.Enabled = false;
            btnGuardar.Visible = false;
            txtLimite1.Text = "C$" + Convert.ToString(Form1.categorias[opc].Limite_Gasto);
            Categoria.calcularPorcentaje(Form1.categorias[opc]);
            try
            { 
                prgGasto1.Value = Convert.ToInt32(Form1.categorias[opc].Porcentaje_Gasto * 100);
            }
            catch
            {
                prgGasto1.Value = 100;
            }
            lblPorcentaje.Text = Convert.ToString(Form1.categorias[opc].Porcentaje_Gasto * 100) + "%";
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            foreach (Categoria cat in Form1.categorias)
            {
                Categoria.calcularPorcentaje(cat);
            }
        }
    }
}
