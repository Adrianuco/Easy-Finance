﻿namespace EasyFinance
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.picIcono = new System.Windows.Forms.PictureBox();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.btnRegresar3 = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblDesc = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.txtTotal1 = new System.Windows.Forms.TextBox();
            this.txtTotal2 = new System.Windows.Forms.TextBox();
            this.lblTotal1 = new System.Windows.Forms.Label();
            this.lblTotal2 = new System.Windows.Forms.Label();
            this.prgGasto1 = new System.Windows.Forms.ProgressBar();
            this.lblCategoría1 = new System.Windows.Forms.Label();
            this.lblProgreso1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nombreGast = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.montoGast = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaGast = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.nombreIng = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.montoIng = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaIng = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblProgreso6 = new System.Windows.Forms.Label();
            this.lblProgreso5 = new System.Windows.Forms.Label();
            this.lblProgreso4 = new System.Windows.Forms.Label();
            this.prgGasto6 = new System.Windows.Forms.ProgressBar();
            this.prgGasto5 = new System.Windows.Forms.ProgressBar();
            this.lblCategoría6 = new System.Windows.Forms.Label();
            this.lblCategoría5 = new System.Windows.Forms.Label();
            this.prgGasto4 = new System.Windows.Forms.ProgressBar();
            this.lblCategoría4 = new System.Windows.Forms.Label();
            this.lblProgreso3 = new System.Windows.Forms.Label();
            this.lblProgreso2 = new System.Windows.Forms.Label();
            this.prgGasto3 = new System.Windows.Forms.ProgressBar();
            this.prgGasto2 = new System.Windows.Forms.ProgressBar();
            this.lblCategoría3 = new System.Windows.Forms.Label();
            this.lblCategoría2 = new System.Windows.Forms.Label();
            this.btnAct = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picIcono)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // picIcono
            // 
            this.picIcono.BackColor = System.Drawing.Color.Transparent;
            this.picIcono.Image = ((System.Drawing.Image)(resources.GetObject("picIcono.Image")));
            this.picIcono.Location = new System.Drawing.Point(251, 10);
            this.picIcono.Margin = new System.Windows.Forms.Padding(2);
            this.picIcono.Name = "picIcono";
            this.picIcono.Size = new System.Drawing.Size(50, 50);
            this.picIcono.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picIcono.TabIndex = 0;
            this.picIcono.TabStop = false;
            // 
            // picLogo
            // 
            this.picLogo.BackColor = System.Drawing.Color.Transparent;
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.Location = new System.Drawing.Point(305, 17);
            this.picLogo.Margin = new System.Windows.Forms.Padding(2);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(120, 35);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 1;
            this.picLogo.TabStop = false;
            // 
            // btnRegresar3
            // 
            this.btnRegresar3.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegresar3.Location = new System.Drawing.Point(398, 401);
            this.btnRegresar3.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegresar3.Name = "btnRegresar3";
            this.btnRegresar3.Size = new System.Drawing.Size(147, 37);
            this.btnRegresar3.TabIndex = 2;
            this.btnRegresar3.Text = "Regresar al Menu";
            this.btnRegresar3.UseVisualStyleBackColor = true;
            this.btnRegresar3.Click += new System.EventHandler(this.btnRegresar3_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Navy;
            this.lblTitulo.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(26, 68);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(127, 17);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Resumen Financiero";
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.BackColor = System.Drawing.Color.Navy;
            this.lblDesc.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc.ForeColor = System.Drawing.Color.White;
            this.lblDesc.Location = new System.Drawing.Point(26, 85);
            this.lblDesc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(598, 17);
            this.lblDesc.TabIndex = 4;
            this.lblDesc.Text = "Visualicé ordenadamente todos los datos ingresados y calculados del programa en u" +
    "n resumen financiero.";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.BackColor = System.Drawing.Color.Transparent;
            this.lblBalance.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.ForeColor = System.Drawing.Color.White;
            this.lblBalance.Location = new System.Drawing.Point(497, 118);
            this.lblBalance.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(54, 14);
            this.lblBalance.TabIndex = 9;
            this.lblBalance.Text = "Balance:";
            // 
            // txtBalance
            // 
            this.txtBalance.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalance.Location = new System.Drawing.Point(421, 134);
            this.txtBalance.Margin = new System.Windows.Forms.Padding(2);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(210, 22);
            this.txtBalance.TabIndex = 10;
            // 
            // txtTotal1
            // 
            this.txtTotal1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal1.Location = new System.Drawing.Point(421, 61);
            this.txtTotal1.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotal1.Name = "txtTotal1";
            this.txtTotal1.Size = new System.Drawing.Size(99, 22);
            this.txtTotal1.TabIndex = 11;
            // 
            // txtTotal2
            // 
            this.txtTotal2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal2.Location = new System.Drawing.Point(527, 61);
            this.txtTotal2.Margin = new System.Windows.Forms.Padding(2);
            this.txtTotal2.Name = "txtTotal2";
            this.txtTotal2.Size = new System.Drawing.Size(99, 22);
            this.txtTotal2.TabIndex = 12;
            // 
            // lblTotal1
            // 
            this.lblTotal1.AutoSize = true;
            this.lblTotal1.BackColor = System.Drawing.Color.Transparent;
            this.lblTotal1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal1.ForeColor = System.Drawing.Color.White;
            this.lblTotal1.Location = new System.Drawing.Point(431, 45);
            this.lblTotal1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotal1.Name = "lblTotal1";
            this.lblTotal1.Size = new System.Drawing.Size(78, 14);
            this.lblTotal1.TabIndex = 13;
            this.lblTotal1.Text = "Total Gastos:";
            // 
            // lblTotal2
            // 
            this.lblTotal2.AutoSize = true;
            this.lblTotal2.BackColor = System.Drawing.Color.Transparent;
            this.lblTotal2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal2.ForeColor = System.Drawing.Color.White;
            this.lblTotal2.Location = new System.Drawing.Point(539, 45);
            this.lblTotal2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotal2.Name = "lblTotal2";
            this.lblTotal2.Size = new System.Drawing.Size(87, 14);
            this.lblTotal2.TabIndex = 14;
            this.lblTotal2.Text = "Total Ingresos:";
            // 
            // prgGasto1
            // 
            this.prgGasto1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.prgGasto1.Location = new System.Drawing.Point(119, 32);
            this.prgGasto1.Margin = new System.Windows.Forms.Padding(2);
            this.prgGasto1.Name = "prgGasto1";
            this.prgGasto1.Size = new System.Drawing.Size(121, 19);
            this.prgGasto1.TabIndex = 15;
            // 
            // lblCategoría1
            // 
            this.lblCategoría1.AutoSize = true;
            this.lblCategoría1.BackColor = System.Drawing.Color.Transparent;
            this.lblCategoría1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoría1.ForeColor = System.Drawing.Color.White;
            this.lblCategoría1.Location = new System.Drawing.Point(44, 32);
            this.lblCategoría1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategoría1.Name = "lblCategoría1";
            this.lblCategoría1.Size = new System.Drawing.Size(66, 14);
            this.lblCategoría1.TabIndex = 16;
            this.lblCategoría1.Text = "Alimentos:";
            // 
            // lblProgreso1
            // 
            this.lblProgreso1.AutoSize = true;
            this.lblProgreso1.BackColor = System.Drawing.Color.Transparent;
            this.lblProgreso1.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgreso1.ForeColor = System.Drawing.Color.White;
            this.lblProgreso1.Location = new System.Drawing.Point(244, 32);
            this.lblProgreso1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgreso1.Name = "lblProgreso1";
            this.lblProgreso1.Size = new System.Drawing.Size(25, 17);
            this.lblProgreso1.TabIndex = 17;
            this.lblProgreso1.Text = "0%";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nombreGast,
            this.montoGast,
            this.fechaGast});
            this.dataGridView1.Location = new System.Drawing.Point(4, 15);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(199, 178);
            this.dataGridView1.TabIndex = 18;
            // 
            // nombreGast
            // 
            this.nombreGast.FillWeight = 117.3787F;
            this.nombreGast.HeaderText = "Nombre";
            this.nombreGast.Name = "nombreGast";
            this.nombreGast.ReadOnly = true;
            // 
            // montoGast
            // 
            this.montoGast.FillWeight = 76.14214F;
            this.montoGast.HeaderText = "Monto";
            this.montoGast.Name = "montoGast";
            this.montoGast.ReadOnly = true;
            // 
            // fechaGast
            // 
            this.fechaGast.FillWeight = 106.4792F;
            this.fechaGast.HeaderText = "Fecha";
            this.fechaGast.Name = "fechaGast";
            this.fechaGast.ReadOnly = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nombreIng,
            this.montoIng,
            this.fechaIng});
            this.dataGridView2.Location = new System.Drawing.Point(207, 15);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(205, 178);
            this.dataGridView2.TabIndex = 19;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // nombreIng
            // 
            this.nombreIng.HeaderText = "Nombre";
            this.nombreIng.Name = "nombreIng";
            this.nombreIng.ReadOnly = true;
            this.nombreIng.Width = 77;
            // 
            // montoIng
            // 
            this.montoIng.HeaderText = "Monto";
            this.montoIng.Name = "montoIng";
            this.montoIng.ReadOnly = true;
            this.montoIng.Width = 50;
            // 
            // fechaIng
            // 
            this.fechaIng.HeaderText = "Fecha";
            this.fechaIng.Name = "fechaIng";
            this.fechaIng.ReadOnly = true;
            this.fechaIng.Width = 77;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(11, 122);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(652, 236);
            this.tabControl1.TabIndex = 20;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightSlateGray;
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.txtTotal1);
            this.tabPage1.Controls.Add(this.lblTotal1);
            this.tabPage1.Controls.Add(this.lblBalance);
            this.tabPage1.Controls.Add(this.txtBalance);
            this.tabPage1.Controls.Add(this.txtTotal2);
            this.tabPage1.Controls.Add(this.lblTotal2);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(644, 209);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Gastos e Ingresos";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightSlateGray;
            this.tabPage2.Controls.Add(this.lblProgreso6);
            this.tabPage2.Controls.Add(this.lblProgreso5);
            this.tabPage2.Controls.Add(this.lblProgreso4);
            this.tabPage2.Controls.Add(this.prgGasto6);
            this.tabPage2.Controls.Add(this.prgGasto5);
            this.tabPage2.Controls.Add(this.lblCategoría6);
            this.tabPage2.Controls.Add(this.lblCategoría5);
            this.tabPage2.Controls.Add(this.prgGasto4);
            this.tabPage2.Controls.Add(this.lblCategoría4);
            this.tabPage2.Controls.Add(this.lblProgreso3);
            this.tabPage2.Controls.Add(this.lblProgreso2);
            this.tabPage2.Controls.Add(this.prgGasto3);
            this.tabPage2.Controls.Add(this.prgGasto2);
            this.tabPage2.Controls.Add(this.lblCategoría3);
            this.tabPage2.Controls.Add(this.lblCategoría2);
            this.tabPage2.Controls.Add(this.lblProgreso1);
            this.tabPage2.Controls.Add(this.lblCategoría1);
            this.tabPage2.Controls.Add(this.prgGasto1);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(644, 209);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Categorías";
            // 
            // lblProgreso6
            // 
            this.lblProgreso6.AutoSize = true;
            this.lblProgreso6.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgreso6.ForeColor = System.Drawing.Color.White;
            this.lblProgreso6.Location = new System.Drawing.Point(578, 170);
            this.lblProgreso6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgreso6.Name = "lblProgreso6";
            this.lblProgreso6.Size = new System.Drawing.Size(25, 17);
            this.lblProgreso6.TabIndex = 32;
            this.lblProgreso6.Text = "0%";
            // 
            // lblProgreso5
            // 
            this.lblProgreso5.AutoSize = true;
            this.lblProgreso5.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgreso5.ForeColor = System.Drawing.Color.White;
            this.lblProgreso5.Location = new System.Drawing.Point(578, 101);
            this.lblProgreso5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgreso5.Name = "lblProgreso5";
            this.lblProgreso5.Size = new System.Drawing.Size(25, 17);
            this.lblProgreso5.TabIndex = 31;
            this.lblProgreso5.Text = "0%";
            // 
            // lblProgreso4
            // 
            this.lblProgreso4.AutoSize = true;
            this.lblProgreso4.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgreso4.ForeColor = System.Drawing.Color.White;
            this.lblProgreso4.Location = new System.Drawing.Point(578, 34);
            this.lblProgreso4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgreso4.Name = "lblProgreso4";
            this.lblProgreso4.Size = new System.Drawing.Size(25, 17);
            this.lblProgreso4.TabIndex = 30;
            this.lblProgreso4.Text = "0%";
            // 
            // prgGasto6
            // 
            this.prgGasto6.Location = new System.Drawing.Point(453, 168);
            this.prgGasto6.Margin = new System.Windows.Forms.Padding(2);
            this.prgGasto6.Name = "prgGasto6";
            this.prgGasto6.Size = new System.Drawing.Size(121, 19);
            this.prgGasto6.TabIndex = 29;
            // 
            // prgGasto5
            // 
            this.prgGasto5.Location = new System.Drawing.Point(453, 99);
            this.prgGasto5.Margin = new System.Windows.Forms.Padding(2);
            this.prgGasto5.Name = "prgGasto5";
            this.prgGasto5.Size = new System.Drawing.Size(121, 19);
            this.prgGasto5.TabIndex = 28;
            // 
            // lblCategoría6
            // 
            this.lblCategoría6.AutoSize = true;
            this.lblCategoría6.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoría6.ForeColor = System.Drawing.Color.White;
            this.lblCategoría6.Location = new System.Drawing.Point(397, 170);
            this.lblCategoría6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategoría6.Name = "lblCategoría6";
            this.lblCategoría6.Size = new System.Drawing.Size(39, 14);
            this.lblCategoría6.TabIndex = 27;
            this.lblCategoría6.Text = "Otros:";
            // 
            // lblCategoría5
            // 
            this.lblCategoría5.AutoSize = true;
            this.lblCategoría5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoría5.ForeColor = System.Drawing.Color.White;
            this.lblCategoría5.Location = new System.Drawing.Point(397, 101);
            this.lblCategoría5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategoría5.Name = "lblCategoría5";
            this.lblCategoría5.Size = new System.Drawing.Size(41, 14);
            this.lblCategoría5.TabIndex = 26;
            this.lblCategoría5.Text = "Salud:";
            // 
            // prgGasto4
            // 
            this.prgGasto4.Location = new System.Drawing.Point(453, 32);
            this.prgGasto4.Margin = new System.Windows.Forms.Padding(2);
            this.prgGasto4.Name = "prgGasto4";
            this.prgGasto4.Size = new System.Drawing.Size(121, 19);
            this.prgGasto4.TabIndex = 25;
            // 
            // lblCategoría4
            // 
            this.lblCategoría4.AutoSize = true;
            this.lblCategoría4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoría4.ForeColor = System.Drawing.Color.White;
            this.lblCategoría4.Location = new System.Drawing.Point(376, 32);
            this.lblCategoría4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategoría4.Name = "lblCategoría4";
            this.lblCategoría4.Size = new System.Drawing.Size(65, 14);
            this.lblCategoría4.TabIndex = 24;
            this.lblCategoría4.Text = "Educación:";
            // 
            // lblProgreso3
            // 
            this.lblProgreso3.AutoSize = true;
            this.lblProgreso3.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgreso3.ForeColor = System.Drawing.Color.White;
            this.lblProgreso3.Location = new System.Drawing.Point(244, 168);
            this.lblProgreso3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgreso3.Name = "lblProgreso3";
            this.lblProgreso3.Size = new System.Drawing.Size(25, 17);
            this.lblProgreso3.TabIndex = 23;
            this.lblProgreso3.Text = "0%";
            // 
            // lblProgreso2
            // 
            this.lblProgreso2.AutoSize = true;
            this.lblProgreso2.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgreso2.ForeColor = System.Drawing.Color.White;
            this.lblProgreso2.Location = new System.Drawing.Point(244, 101);
            this.lblProgreso2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProgreso2.Name = "lblProgreso2";
            this.lblProgreso2.Size = new System.Drawing.Size(25, 17);
            this.lblProgreso2.TabIndex = 22;
            this.lblProgreso2.Text = "0%";
            // 
            // prgGasto3
            // 
            this.prgGasto3.Location = new System.Drawing.Point(119, 168);
            this.prgGasto3.Margin = new System.Windows.Forms.Padding(2);
            this.prgGasto3.Name = "prgGasto3";
            this.prgGasto3.Size = new System.Drawing.Size(121, 19);
            this.prgGasto3.TabIndex = 21;
            // 
            // prgGasto2
            // 
            this.prgGasto2.Location = new System.Drawing.Point(119, 99);
            this.prgGasto2.Margin = new System.Windows.Forms.Padding(2);
            this.prgGasto2.Name = "prgGasto2";
            this.prgGasto2.Size = new System.Drawing.Size(121, 19);
            this.prgGasto2.TabIndex = 20;
            // 
            // lblCategoría3
            // 
            this.lblCategoría3.AutoSize = true;
            this.lblCategoría3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoría3.ForeColor = System.Drawing.Color.White;
            this.lblCategoría3.Location = new System.Drawing.Point(42, 104);
            this.lblCategoría3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategoría3.Name = "lblCategoría3";
            this.lblCategoría3.Size = new System.Drawing.Size(68, 14);
            this.lblCategoría3.TabIndex = 19;
            this.lblCategoría3.Text = "Transporte:";
            // 
            // lblCategoría2
            // 
            this.lblCategoría2.AutoSize = true;
            this.lblCategoría2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoría2.ForeColor = System.Drawing.Color.White;
            this.lblCategoría2.Location = new System.Drawing.Point(16, 170);
            this.lblCategoría2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategoría2.Name = "lblCategoría2";
            this.lblCategoría2.Size = new System.Drawing.Size(99, 14);
            this.lblCategoría2.TabIndex = 18;
            this.lblCategoría2.Text = "Entretenimiento:";
            // 
            // btnAct
            // 
            this.btnAct.Location = new System.Drawing.Point(162, 403);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(139, 35);
            this.btnAct.TabIndex = 21;
            this.btnAct.Text = "Actualizar";
            this.btnAct.UseVisualStyleBackColor = true;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(670, 449);
            this.Controls.Add(this.btnAct);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblDesc);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnRegresar3);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.picIcono);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EasyFinance";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RegresarMenu3);
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picIcono)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picIcono;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Button btnRegresar3;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtTotal1;
        private System.Windows.Forms.TextBox txtTotal2;
        private System.Windows.Forms.Label lblTotal1;
        private System.Windows.Forms.Label lblTotal2;
        private System.Windows.Forms.ProgressBar prgGasto1;
        private System.Windows.Forms.Label lblCategoría1;
        private System.Windows.Forms.Label lblProgreso1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblCategoría3;
        private System.Windows.Forms.Label lblCategoría2;
        private System.Windows.Forms.ProgressBar prgGasto3;
        private System.Windows.Forms.ProgressBar prgGasto2;
        private System.Windows.Forms.Label lblProgreso2;
        private System.Windows.Forms.Label lblProgreso3;
        private System.Windows.Forms.ProgressBar prgGasto4;
        private System.Windows.Forms.Label lblCategoría4;
        private System.Windows.Forms.ProgressBar prgGasto6;
        private System.Windows.Forms.ProgressBar prgGasto5;
        private System.Windows.Forms.Label lblCategoría6;
        private System.Windows.Forms.Label lblCategoría5;
        private System.Windows.Forms.Label lblProgreso6;
        private System.Windows.Forms.Label lblProgreso5;
        private System.Windows.Forms.Label lblProgreso4;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreGast;
        private System.Windows.Forms.DataGridViewTextBoxColumn montoGast;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaGast;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreIng;
        private System.Windows.Forms.DataGridViewTextBoxColumn montoIng;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaIng;
        private System.Windows.Forms.Button btnAct;
    }
}