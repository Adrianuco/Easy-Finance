﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace EasyFinance
{
    public partial class Form4 : Form
    {
        private Form1 ventana1;

        public Form4(Form1 menu)
        {
            InitializeComponent();
            ventana1 = menu;
        }

        private void btnRegresar3_Click(object sender, EventArgs e)
        {
            this.Close();
            ventana1.Visible = true;
        }

        private void RegresarMenu3(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Visible = false;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            

        }

        
        private void cmbMes_SelectedIndexChanged(object sender, EventArgs e)
        {
           

            

        }
        
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAct_Click(object sender, EventArgs e)
        {
            double gastos = 0;
            double ingresos = 0;

            // Limpiar los DataGridView
            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();

            // Filtrar y sumar gastos
            foreach (Gasto gasto in Form2.gastos)
            {

                dataGridView1.Rows.Add(gasto.Nombre, gasto.Monto, gasto.Fecha.ToShortDateString());
                gastos += gasto.Monto;

            }

            // Filtrar y sumar ingresos
            foreach (Ingreso ingreso in Form2.ingresos)
            {

                dataGridView2.Rows.Add(ingreso.nombre, ingreso.monto, ingreso.fecha.ToShortDateString());
                ingresos += ingreso.monto;

            }

            // Actualizar totales
            txtTotal1.Text = "C$" + gastos.ToString();
            txtTotal2.Text = "C$" + ingresos.ToString();
            txtBalance.Text = "C$" + (ingresos - gastos).ToString();


            lblProgreso1.Text = (Form1.categorias[0].Porcentaje_Gasto * 100).ToString("0.00") + "%";
            prgGasto1.Value = Convert.ToInt32(Form1.categorias[0].Porcentaje_Gasto * 100);

            lblProgreso2.Text = (Form1.categorias[1].Porcentaje_Gasto * 100).ToString("0.00") + "%";
            prgGasto2.Value = Convert.ToInt32(Form1.categorias[1].Porcentaje_Gasto * 100);

            lblProgreso3.Text = (Form1.categorias[2].Porcentaje_Gasto * 100).ToString("0.00") + "%";
            prgGasto3.Value = Convert.ToInt32(Form1.categorias[2].Porcentaje_Gasto * 100);

            lblProgreso4.Text = (Form1.categorias[3].Porcentaje_Gasto * 100).ToString("0.00") + "%";
            prgGasto4.Value = Convert.ToInt32(Form1.categorias[3].Porcentaje_Gasto * 100);

            lblProgreso5.Text = (Form1.categorias[4].Porcentaje_Gasto * 100).ToString("0.00") + "%";
            prgGasto5.Value = Convert.ToInt32(Form1.categorias[4].Porcentaje_Gasto * 100);

            lblProgreso6.Text = (Form1.categorias[5].Porcentaje_Gasto * 100).ToString("0.00") + "%";
            prgGasto6.Value = Convert.ToInt32(Form1.categorias[5].Porcentaje_Gasto * 100);
        }
    }
}
