﻿namespace EasyFinance
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblDesc1 = new System.Windows.Forms.Label();
            this.lblDesc2 = new System.Windows.Forms.Label();
            this.lblRegistro = new System.Windows.Forms.Label();
            this.lblDesc3 = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.lblCategorías = new System.Windows.Forms.Label();
            this.lblDesc4 = new System.Windows.Forms.Label();
            this.lblDesc5 = new System.Windows.Forms.Label();
            this.btnCategorías = new System.Windows.Forms.Button();
            this.lblResumen = new System.Windows.Forms.Label();
            this.lblDesc6 = new System.Windows.Forms.Label();
            this.lblDesc7 = new System.Windows.Forms.Label();
            this.btnResumen = new System.Windows.Forms.Button();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Navy;
            this.lblTitulo.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(9, 15);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(170, 17);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "¡Bienvenido a EasyFinance!";
            // 
            // lblDesc1
            // 
            this.lblDesc1.AutoSize = true;
            this.lblDesc1.BackColor = System.Drawing.Color.Navy;
            this.lblDesc1.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc1.ForeColor = System.Drawing.Color.White;
            this.lblDesc1.Location = new System.Drawing.Point(9, 32);
            this.lblDesc1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc1.Name = "lblDesc1";
            this.lblDesc1.Size = new System.Drawing.Size(649, 17);
            this.lblDesc1.TabIndex = 1;
            this.lblDesc1.Text = "¡Bienvenido al programa definitivo del manejo de sus finanzas personales, donde p" +
    "odrá registrar todos sus gastos e";
            // 
            // lblDesc2
            // 
            this.lblDesc2.AutoSize = true;
            this.lblDesc2.BackColor = System.Drawing.Color.Navy;
            this.lblDesc2.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc2.ForeColor = System.Drawing.Color.White;
            this.lblDesc2.Location = new System.Drawing.Point(9, 49);
            this.lblDesc2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc2.Name = "lblDesc2";
            this.lblDesc2.Size = new System.Drawing.Size(410, 17);
            this.lblDesc2.TabIndex = 2;
            this.lblDesc2.Text = "ingresos del mes para un mejor seguimiento de todas sus transacciones!";
            // 
            // lblRegistro
            // 
            this.lblRegistro.AutoSize = true;
            this.lblRegistro.BackColor = System.Drawing.Color.Transparent;
            this.lblRegistro.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistro.ForeColor = System.Drawing.Color.White;
            this.lblRegistro.Location = new System.Drawing.Point(16, 93);
            this.lblRegistro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRegistro.Name = "lblRegistro";
            this.lblRegistro.Size = new System.Drawing.Size(113, 17);
            this.lblRegistro.TabIndex = 3;
            this.lblRegistro.Text = "Registro de Datos";
            // 
            // lblDesc3
            // 
            this.lblDesc3.AutoSize = true;
            this.lblDesc3.BackColor = System.Drawing.Color.Transparent;
            this.lblDesc3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc3.ForeColor = System.Drawing.Color.White;
            this.lblDesc3.Location = new System.Drawing.Point(17, 110);
            this.lblDesc3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc3.Name = "lblDesc3";
            this.lblDesc3.Size = new System.Drawing.Size(343, 14);
            this.lblDesc3.TabIndex = 4;
            this.lblDesc3.Text = "Agregue o actualice todos los datos de sus gastos e ingresos.";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.Location = new System.Drawing.Point(20, 134);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(195, 37);
            this.btnRegistrar.TabIndex = 5;
            this.btnRegistrar.Text = "Registrar Datos";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // lblCategorías
            // 
            this.lblCategorías.AutoSize = true;
            this.lblCategorías.BackColor = System.Drawing.Color.Transparent;
            this.lblCategorías.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategorías.ForeColor = System.Drawing.Color.White;
            this.lblCategorías.Location = new System.Drawing.Point(17, 196);
            this.lblCategorías.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCategorías.Name = "lblCategorías";
            this.lblCategorías.Size = new System.Drawing.Size(70, 17);
            this.lblCategorías.TabIndex = 6;
            this.lblCategorías.Text = "Categorías";
            // 
            // lblDesc4
            // 
            this.lblDesc4.AutoSize = true;
            this.lblDesc4.BackColor = System.Drawing.Color.Transparent;
            this.lblDesc4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc4.ForeColor = System.Drawing.Color.White;
            this.lblDesc4.Location = new System.Drawing.Point(18, 213);
            this.lblDesc4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc4.Name = "lblDesc4";
            this.lblDesc4.Size = new System.Drawing.Size(341, 14);
            this.lblDesc4.TabIndex = 7;
            this.lblDesc4.Text = "Observe el porcentaje de sus gastos y asigne un presupuesto";
            // 
            // lblDesc5
            // 
            this.lblDesc5.AutoSize = true;
            this.lblDesc5.BackColor = System.Drawing.Color.Transparent;
            this.lblDesc5.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc5.ForeColor = System.Drawing.Color.White;
            this.lblDesc5.Location = new System.Drawing.Point(18, 228);
            this.lblDesc5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc5.Name = "lblDesc5";
            this.lblDesc5.Size = new System.Drawing.Size(117, 14);
            this.lblDesc5.TabIndex = 8;
            this.lblDesc5.Text = "para cada categoría.";
            // 
            // btnCategorías
            // 
            this.btnCategorías.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCategorías.Location = new System.Drawing.Point(20, 252);
            this.btnCategorías.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCategorías.Name = "btnCategorías";
            this.btnCategorías.Size = new System.Drawing.Size(195, 37);
            this.btnCategorías.TabIndex = 9;
            this.btnCategorías.Text = "Ver Categorías";
            this.btnCategorías.UseVisualStyleBackColor = true;
            this.btnCategorías.Click += new System.EventHandler(this.btnCategorías_Click);
            // 
            // lblResumen
            // 
            this.lblResumen.AutoSize = true;
            this.lblResumen.BackColor = System.Drawing.Color.Transparent;
            this.lblResumen.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumen.ForeColor = System.Drawing.Color.White;
            this.lblResumen.Location = new System.Drawing.Point(17, 311);
            this.lblResumen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResumen.Name = "lblResumen";
            this.lblResumen.Size = new System.Drawing.Size(127, 17);
            this.lblResumen.TabIndex = 10;
            this.lblResumen.Text = "Resumen Financiero";
            // 
            // lblDesc6
            // 
            this.lblDesc6.AutoSize = true;
            this.lblDesc6.BackColor = System.Drawing.Color.Transparent;
            this.lblDesc6.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc6.ForeColor = System.Drawing.Color.White;
            this.lblDesc6.Location = new System.Drawing.Point(18, 328);
            this.lblDesc6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc6.Name = "lblDesc6";
            this.lblDesc6.Size = new System.Drawing.Size(352, 14);
            this.lblDesc6.TabIndex = 11;
            this.lblDesc6.Text = "Generar y visualizar el resumen  de todos los datos ingresados";
            // 
            // lblDesc7
            // 
            this.lblDesc7.AutoSize = true;
            this.lblDesc7.BackColor = System.Drawing.Color.Transparent;
            this.lblDesc7.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesc7.ForeColor = System.Drawing.Color.White;
            this.lblDesc7.Location = new System.Drawing.Point(18, 343);
            this.lblDesc7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDesc7.Name = "lblDesc7";
            this.lblDesc7.Size = new System.Drawing.Size(77, 14);
            this.lblDesc7.TabIndex = 12;
            this.lblDesc7.Text = "y calculados.";
            // 
            // btnResumen
            // 
            this.btnResumen.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResumen.ForeColor = System.Drawing.Color.Black;
            this.btnResumen.Location = new System.Drawing.Point(20, 368);
            this.btnResumen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnResumen.Name = "btnResumen";
            this.btnResumen.Size = new System.Drawing.Size(195, 37);
            this.btnResumen.TabIndex = 13;
            this.btnResumen.Text = "Generar Resumen Financiero";
            this.btnResumen.UseVisualStyleBackColor = true;
            this.btnResumen.Click += new System.EventHandler(this.btnResumen_Click);
            // 
            // picLogo
            // 
            this.picLogo.BackColor = System.Drawing.Color.Transparent;
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.Location = new System.Drawing.Point(388, 93);
            this.picLogo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(274, 236);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 14;
            this.picLogo.TabStop = false;
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.Black;
            this.btnSalir.Location = new System.Drawing.Point(512, 401);
            this.btnSalir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(147, 37);
            this.btnSalir.TabIndex = 15;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnReset
            // 
            this.btnReset.ForeColor = System.Drawing.Color.Red;
            this.btnReset.Location = new System.Drawing.Point(340, 402);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(126, 34);
            this.btnReset.TabIndex = 16;
            this.btnReset.Text = "Guardar y Resetear";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(670, 449);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.btnResumen);
            this.Controls.Add(this.lblDesc7);
            this.Controls.Add(this.lblDesc6);
            this.Controls.Add(this.lblResumen);
            this.Controls.Add(this.btnCategorías);
            this.Controls.Add(this.lblDesc5);
            this.Controls.Add(this.lblDesc4);
            this.Controls.Add(this.lblCategorías);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.lblDesc3);
            this.Controls.Add(this.lblRegistro);
            this.Controls.Add(this.lblDesc2);
            this.Controls.Add(this.lblDesc1);
            this.Controls.Add(this.lblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EasyFinance";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblDesc1;
        private System.Windows.Forms.Label lblDesc2;
        private System.Windows.Forms.Label lblRegistro;
        private System.Windows.Forms.Label lblDesc3;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Label lblCategorías;
        private System.Windows.Forms.Label lblDesc4;
        private System.Windows.Forms.Label lblDesc5;
        private System.Windows.Forms.Button btnCategorías;
        private System.Windows.Forms.Label lblResumen;
        private System.Windows.Forms.Label lblDesc6;
        private System.Windows.Forms.Label lblDesc7;
        private System.Windows.Forms.Button btnResumen;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnReset;
    }
}

