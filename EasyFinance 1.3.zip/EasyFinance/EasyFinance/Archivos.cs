﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyFinance
{
    internal class Archivos
    {
        public static void guardarGastos(List<Gasto> gastos)
        {
            using (FileStream file = new FileStream("gastos.txt", FileMode.Create))
            {
                using (BinaryWriter writer = new BinaryWriter(file, Encoding.UTF8))
                {
                    foreach (Gasto gasto in gastos)
                    {
                        writer.Write(gasto.Nombre);
                        writer.Write(gasto.Monto);
                        writer.Write(gasto.Fecha.Ticks);
                        writer.Write(gasto.Categoria);
                    }
                }
            }
        }
        
        public static void leerGastos(List<Gasto> gastos)
        {
            if (File.Exists("gastos.txt"))
            {
                using (FileStream file = new FileStream("gastos.txt", FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(file, Encoding.UTF8))
                    {
                        while (reader.BaseStream.Position != reader.BaseStream.Length)
                        {
                            string nombre = reader.ReadString();
                            double monto = reader.ReadDouble();
                            DateTime fecha = new DateTime(reader.ReadInt64());
                            string categoria = reader.ReadString();
                            Gasto.registrarGasto(gastos, nombre, monto, fecha, categoria);
                        }
                    }
                }
            }
        }
        
        public static void guardarIngresos(List<Ingreso> ingresos)
        {
            using (FileStream file = new FileStream("ingresos.txt", FileMode.Create))
            {
                using (BinaryWriter writer = new BinaryWriter(file, Encoding.UTF8))
                {
                    foreach (Ingreso ingreso in ingresos)
                    {
                        writer.Write(ingreso.nombre);
                        writer.Write(ingreso.monto);
                        writer.Write(ingreso.fecha.Ticks);
                    }
                }
            }
        }
        public static void leerIngresos(List<Ingreso> ingresos)
        {
            if (File.Exists("ingresos.txt"))
            {
                using (FileStream file = new FileStream("ingresos.txt", FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(file, Encoding.UTF8))
                    {
                        while (reader.BaseStream.Position != reader.BaseStream.Length)
                        {
                            string nombre = reader.ReadString();
                            double monto = reader.ReadDouble();
                            DateTime fecha = new DateTime(reader.ReadInt64());
                            Ingreso.registrarIngreso(ingresos, nombre, monto, fecha);
                        }
                    }
                }
            }
        }

        public static void guardarCategorias(List<Categoria> categorias)
        {
            using (FileStream file = new FileStream("categorias.txt", FileMode.Create))
            {
                using (BinaryWriter writer = new BinaryWriter(file, Encoding.UTF8))
                {
                    foreach (Categoria categoria in categorias)
                    {
                        writer.Write(categoria.Nombre);
                        writer.Write(categoria.Limite_Gasto);
                        writer.Write(categoria.Porcentaje_Gasto);
                        writer.Write(categoria.monto);
                        writer.Write(categoria.Alerta);
                    }
                }
            }
        }

        public static void leerCategoria(List<Categoria> categorias)
        {
            if (File.Exists("categorias.txt"))
            {
                using (FileStream file = new FileStream("categorias.txt", FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(file, Encoding.UTF8))
                    {
                        while (reader.BaseStream.Position != reader.BaseStream.Length)
                        {
                            string nombre = reader.ReadString();
                            double limite_gasto = reader.ReadDouble();
                            float porcentaje_gasto = reader.ReadSingle();
                            double monto = reader.ReadDouble();
                            bool alerta = reader.ReadBoolean();
                            Categoria categoria = new Categoria(nombre, limite_gasto, porcentaje_gasto);
                            categoria.monto = monto;
                            categoria.Alerta = alerta;
                            categorias.Add(categoria);
                        }
                    }
                }
            }
            else
            {
                categorias.Add(new Categoria("Alimentos", 1000, 0.0f));
                categorias.Add(new Categoria("Transporte", 1000, 0.0f));
                categorias.Add(new Categoria("Entretenimiento", 1000, 0.0f));
                categorias.Add(new Categoria("Educacion", 1000, 0.0f));
                categorias.Add(new Categoria("Salud", 1000, 0.0f));
                categorias.Add(new Categoria("Otros", 1000, 0.0f));
            }
        }
    }
}
